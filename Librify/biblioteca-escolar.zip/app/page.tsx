"use client"

import  from "../lib/auth"

export default function SyntheticV0PageForDeployment() {
  return < />
}